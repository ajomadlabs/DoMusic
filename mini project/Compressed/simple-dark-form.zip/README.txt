A Pen created at CodePen.io. You can find this one at http://codepen.io/oceatoon/pen/IeqHp.

 Simple form based on Andreas Storm work.